/*
 * server_multiple.c
 *
 *  Created on: 25-Sep-2024
 *      Author: AvionicsTestHarshith
 */


#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <syslog.h>
#include <unistd.h>
#include<arpa/inet.h>
#include<sys/time.h>
#include<time.h>
#include<sys/socket.h>
#include<sys/types.h>
#include<netinet/in.h>
#include<fcntl.h>
#include<unistd.h>
#include<pthread.h>

#include <zds_p2p_init.h>
#include <zds_cnc_configuration.h>
#include <zds_cnc_init.h>
#include <zds_p2p_send.h>
#include <zds_p2p.h>
#include <zds_cnc.h>

#define SERVER_IP "127.0.0.1"
#define MAX_PORTS 5


typedef struct {
    uint8_t send_command;

}server_send_t;

s_configuration *configuration; /* For processing initialization */
s_p2p_communication *p2p_communication_p; /* For processing initialization */
s_configuration *configuration; /* For processing initialization */
s_p2p_communication *p2p_communication_p; /* For processing initialization */
uint16_t ui16_current_max_value = 0;

void handle_acquisition_0(uint16_t id, uint64_t timestamp, uint16_t length,
uint16_t *value);
void server_connect();

void *server(void* arg);

/* Main program */
int main (int argc, char *argv[])
{
      /* zds CnC Initialization*/
      if (zds_cnc_initialize(&configuration)!=0)
      {
        syslog(LOG_ERR, "Cannot initialize zds cnc\n");
        exit(1);
      }
     /* zds P2P Initialization*/
     if (zds_p2p_initialize(configuration, ZDS_USE_HANDLER, &p2p_communication_p ) != 0)
     {
        syslog(LOG_ERR, "Cannot initialize zds p2p\n");
     }
     /* Parameters retrieval */
     server_send_t sending;
     /* copy of alpha value as double into double_alpha */
     zds_cnc_configuration_get_parameter(configuration, 0,&sending);
      /* conversion into float */

      /* Endless loop */
       /* MODIFY ENDLESS LOOP IF YOU NEED TO OUPUT DATA WITHOUT THE INPUT HANDLERS DEFINED
       ABOVE */
      while(1)
      {
          usleep(1000*1000);
      }
      return 0;
}

void handle_acquisition_0(uint16_t id, uint64_t timestamp, uint16_t length, uint16_t
*value)
{
	server_connect();
	zds_p2p_send_acquisition_synchronous(p2p_communication_p,

	0 /* output order 1 */,
	timestamp /* same timestamp as input */,
	&ui16_current_max_value, /* payload as array of uint16_t */
	1,
	1); /* length of the array */
}

void *server(void* arg)
{

    int e,n;
    int i;
    int serversocket,clientsocket;
    struct sockaddr_in servaddr,clientaddr;
    socklen_t addr_size;
    int port = *((int*)arg);
    struct timespec trig_time;
    serversocket=socket(AF_INET,SOCK_STREAM,0);
    if(serversocket == -1)
    {
       printf("socket creation failed\n");
       exit(1);
    }
    printf("Socket successfully created\n");
        //assign IP Address

    servaddr.sin_family=AF_INET;
    servaddr.sin_port = htons(port);
    servaddr.sin_addr.s_addr=inet_addr("127.0.0.1");

    printf("Before Binding\n");
    e=bind(serversocket,(struct sockaddr*)&servaddr,sizeof(servaddr));
    if(e<0)
    {
	    perror("Error in binding123\n");
	    exit(1);
    }
    printf("Binding Successful\n");
    n=listen(serversocket,10);
    if(n<0)
    {
	     perror("Failed to listen for connections\n");
	     exit(1);
    }
    addr_size=sizeof(clientaddr);
    printf("Listening\n");
        if(port == 6321)
        {
            int frequency = 1;
            clientsocket=accept(serversocket,(struct sockaddr*)&clientaddr,&addr_size);
            if(clientsocket<0)
            {
	            perror("error in accepting connection\n");
	            exit(1);
            }

            else
            {
	            printf("Sending\n");
	            server_send_t sending={.send_command=1};
                uint64_t period = (uint64_t)(1000000000/frequency);
	            trig_time.tv_sec = period/1000000000;
	            trig_time.tv_nsec = period%1000000000;

                for( i = 0; i < 10 ; i++)
                {

	                if(send(clientsocket,(void *)&sending,sizeof(sending),0)==-1)
	                {
	                   perror("Error in sending\n");
	                }

                    if(nanosleep(&trig_time, NULL)==-1){
                        perror("Error in nanosleep\n");
                        exit(1);
                    }

                    // sleep(1);
	                printf("send_command is:%d\n",sending.send_command);

                }
            }
        }
        else if(port == 6322)
        {
            int frequency = 10;
            clientsocket=accept(serversocket,(struct sockaddr*)&clientaddr,&addr_size);
            if(clientsocket<0)
            {
	            perror("error in accepting connection\n");
	            exit(1);
            }

            else
            {
	            printf("Sending\n");
	            struct timeval St;
	            gettimeofday(&St,NULL);
	            server_send_t sending={.send_command=2};
                uint64_t period = (uint64_t)(1000000000/frequency);
	            trig_time.tv_sec = period/1000000000;
	            trig_time.tv_nsec = period%1000000000;

                for( i = 0; i < 10 ; i++)
                {

	                if(send(clientsocket,(void *)&sending,sizeof(sending),0)==-1)
	                {
	                   perror("Error in sending\n");
	                }
                    nanosleep(&trig_time, NULL);
	                printf("send_command is:%d\n",sending.send_command);

                }
            }
        }
        else if(port == 6323)
        {
            int frequency = 100;
            clientsocket=accept(serversocket,(struct sockaddr*)&clientaddr,&addr_size);
            if(clientsocket<0)
            {
	            perror("error in accepting connection\n");
	            exit(1);
            }

            else
            {
	            printf("Sending\n");
	            server_send_t sending={.send_command=3};
                // sleep_time.tv_nsec = 1000000000 / frequency;

                uint64_t period = (uint64_t)(1000000000/frequency);
	            trig_time.tv_sec = period/1000000000;
	            trig_time.tv_nsec = period%1000000000;

                for( i = 0; i < 10 ; i++)
                {

	                if(send(clientsocket,(void *)&sending,sizeof(sending),0)==-1)
	                {
	                   perror("Error in sending\n");
	                }
                    nanosleep(&trig_time, NULL);
	                printf("send_command is:%d\n",sending.send_command);

                }
            }
        }


        else if(port == 6324)
        {
            int frequency = 1000;
            clientsocket=accept(serversocket,(struct sockaddr*)&clientaddr,&addr_size);
            if(clientsocket<0)
            {
	            perror("error in accepting connection\n");
	            exit(1);
            }

            else
            {
	            printf("Sending\n");
	            server_send_t sending={.send_command=4};
                // sleep_time.tv_nsec = 1000000000 / frequency;

                uint64_t period = (uint64_t)(1000000000/frequency);
	            trig_time.tv_sec = period/1000000000;
	            trig_time.tv_nsec = period%1000000000;

                for( i = 0; i < 10 ; i++)
                {

	                if(send(clientsocket,(void *)&sending,sizeof(sending),0)==-1)
	                {
	                   perror("Error in sending\n");
	                }
                    nanosleep(&trig_time, NULL);
	                printf("send_command is:%d\n",sending.send_command);

                }
            }
        }
        if(port == 6325)
        {
            int frequency = 2000;
            clientsocket=accept(serversocket,(struct sockaddr*)&clientaddr,&addr_size);
            if(clientsocket<0)
            {
	            perror("error in accepting connection\n");
	            exit(1);
            }

            else
            {
	            printf("Sending\n");
	            server_send_t sending={.send_command=5};
                // sleep_time.tv_nsec = 1000000000 / frequency;

                uint64_t period = (uint64_t)(1000000000/frequency);
	            trig_time.tv_sec = period/1000000000;
	            trig_time.tv_nsec = period%1000000000;

                for( i = 0; i < 10 ; i++)
                {

	                if(send(clientsocket,(void *)&sending,sizeof(sending),0)==-1)
	                {
	                   perror("Error in sending\n");
	                }
                    nanosleep(&trig_time, NULL);
	                printf("send_command is:%d\n",sending.send_command);

                }
            }
        }

}

void server_connect()
{
    int ports[MAX_PORTS] = {6321, 6322, 6323, 6324, 6325};
    int i;

    // Create multiple threads to listen on different ports
    pthread_t server_threads[MAX_PORTS];

    for (i = 0; i < MAX_PORTS; i++) {
        pthread_create(&server_threads[i], NULL, (void*)server, (void*)&ports[i]);
    }

    // Wait for all server threads to finish
    for ( i = 0; i < MAX_PORTS; i++) {
        pthread_join(server_threads[i], NULL);
    }

}
