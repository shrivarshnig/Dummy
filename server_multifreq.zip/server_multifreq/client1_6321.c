#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<arpa/inet.h>
#include<sys/time.h>
#include<time.h>
#include <pthread.h>

#define port 6321
#define IP ("127.0.0.2")

#define BUFFER_SIZE 1024
#define TARGET_RATE_MBPS_1 1024
int main()
{ 
    printf("client-1\n");
    socklen_t addr_size;
    struct sockaddr_in ats_clientaddress;
    int sockfd;
    struct timespec sleep_time1 = {0};
    struct timespec trig_time;
    char ch;
    
    addr_size=sizeof(ats_clientaddress); 
 
 
    // int port = *((int*)arg);

    /*Socket creation*/
    sockfd = socket(AF_INET, SOCK_STREAM, 0);

    if(sockfd<0)
    {
      printf("error in socket creation");
    }

    printf("socket creation is successful\n");

    /*Assigning port number and IP_ADDRESS*/
    ats_clientaddress.sin_family = AF_INET;
    ats_clientaddress.sin_addr.s_addr = inet_addr(IP);
    ats_clientaddress.sin_port = htons(port);

    /*Connect to the client*/
    if (connect(sockfd, (struct sockaddr *)&ats_clientaddress,sizeof(ats_clientaddress)) == -1) 
    {
        perror("Connection failed");
        exit(1);
    }
    printf("connected successfully\n");



    printf("got successfully\n");
    char buffer_1[BUFFER_SIZE]={"hi"};  // Buffer to hold data
    long target_rate_bps_1 = 1024/8;  // Convert to bytes per second
    long total_bytes_sent_1 = 0;
     int frequency1 = 1;
    uint64_t period = (uint64_t)(1000000000/frequency1);
    trig_time.tv_sec = period/1000000000;
    trig_time.tv_nsec = period%1000000000;
    while (total_bytes_sent_1 < target_rate_bps_1) 
    {  
       
        ssize_t bytes_sent_1 = send(sockfd, buffer_1, BUFFER_SIZE, 0);
        if(bytes_sent_1 <=0)
        {
            perror("Error in receiving\n");

            exit(1);

        }
        nanosleep(&trig_time, NULL);
        total_bytes_sent_1+=bytes_sent_1;
        printf("%s\n",buffer_1);
    }
    printf("Sent for port1 %ld bytes at %ld Mbps.\n", total_bytes_sent_1, TARGET_RATE_MBPS_1);   
    

}
