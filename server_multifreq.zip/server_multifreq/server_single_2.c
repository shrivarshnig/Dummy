#include "main.h"

#define IP_ADD "127.0.0.1"

static int g_index[] = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16};
static int ip_port[] = {6321,6322,6323,6324,6325,6326,6327,6328,6329,6330,6331,6332,6333};
static int frequence[] = {1,10,25,61,100,125,250,500,1000,2000,5000,10000,20000};
static char *file_namw[] ={"port_1.csv","port_2.csv","port_3.csv","port_4.csv","port_5.csv","port_6.csv","port_7.csv","port_8.csv","port_9.csv","port_10.csv",
"port_11.csv","port_12.csv","port_13.csv"};
static int target_rate_bps_1[] = {128,1280,3200,7808,12800,16000,32000,64000,128000,256000,640000,1280000,2560000};
#define BUFFER_SIZE 1024

int main()
{
    
    if(-1 == prctl(PR_SET_NAME, "TCP_PROC", NULL,NULL,NULL))
	{
		exit(EXIT_FAILURE);
	}
	
    for (int i = 0; i < 1; i++)
	{
		// printf("main process %d\n",getpid());
		/**< If start communicating with the telemtry, if it is enabled.*/
        pthread_t thread_id;
        int status = pthread_create(&thread_id, NULL,handle_tcp_channel, (void*)&g_index[i]);
        pthread_detach(thread_id);
        if (status != 0)
        {
            printf("Unable to initialize thread\n");
            exit(EXIT_FAILURE);
        }
		printf("%d\n",g_index[i]);
    }
	while (1) {
    	pause();
    }
}

static void *handle_tcp_channel(void *data)
{
	
    int th_index = -1;
	th_index = *((int*)data);
	printf("inside %d\n",th_index);
    thread_info telemetry_threads;

	/**< Some timer stuff.*/
	atomic_store(&(telemetry_threads.kthread_ID), syscall(SYS_gettid));

	char *ip = IP_ADD;
    int port = ip_port[th_index];


    int server_sock, client_sock;
    struct sockaddr_in server_addr, client_addr;
    socklen_t addr_size;

    /*socket*/
    server_sock = socket(AF_INET, SOCK_STREAM, 0);

    if (server_sock < 0)
    {
        perror("ERROR: Socket is Fail...");
        return 0;
    }
    printf("Socket is creat successfully...\n");

    server_addr.sin_family = AF_INET;
    server_addr.sin_port = port;
    server_addr.sin_addr.s_addr = INADDR_ANY;

    int b = bind(server_sock, (struct sockaddr*)&server_addr, sizeof(server_addr));

    if(b < 0)
    {
        printf("ERROR: Bind is Fail...\n");
        return 0;
    }
    printf("Bind is create Successfully...\n");

    listen(server_sock, 5);
    printf(".....Waiting.....\n");

    /*accept*/
    addr_size = sizeof(client_addr);
    client_sock = accept(server_sock, (struct sockaddr*)&client_addr, &addr_size);
    printf("client is connected...\n");

	/**<Defines which signals to wait for */
	sigset_t set;
	
	/**< Use a unique signal number for each thread. */
	int signum = SIGRTMIN + th_index;

	/** Convert the frequency in LUT to period in nanoseconds.*/
	uint64_t period = (uint64_t)(1000000000/frequence[th_index]);
	
	/**< Store the period in the thread info struct. */
	telemetry_threads.trig_time.tv_sec = period/1000000000;
	telemetry_threads.trig_time.tv_nsec = period%1000000000;

	/**< Initialize the timer and bind it to the signal number.*/
	if(init_thread_timer(&telemetry_threads, signum) == -1)
	{
		printf("error\n");
	}

	/**< Start the timer in REPEAT mode*/
	if(start_timer(telemetry_threads.timer_ID, REPEAT, 
					 &(telemetry_threads.trig_time)) == -1)
	{
		printf("error\n");
		pthread_exit(NULL);
	}

	/**< Set the signal mask for this thread*/
	set_procmask(&set, signum);
	int g_timer_count=0;
    char buffer_1[BUFFER_SIZE];  
    int total_bytes_received_1 = 0;
	/**< Create a buffer of size specified in the LUT*/
    FILE *fd=fopen(file_namw[th_index],"w");
    if(fd==NULL)
    {
        printf("empty file\n");
    }
	
	while(1)
	{
		printf("hello im waiting\n");
		sigwait(&set, &signum); 
        ssize_t bytes_received_1 =recv(client_sock, buffer_1,BUFFER_SIZE, 0);
        if(bytes_received_1<0)
        {
            perror("Error in sending-1\n");
        }	
        total_bytes_received_1 += bytes_received_1;
        fprintf(fd,"port 1 %d Received %ld bytes. Total received: %d bytes\n",port, bytes_received_1, total_bytes_received_1);
        fflush(fd);
        if(total_bytes_received_1 < target_rate_bps_1[th_index])
        {
            break;
        }
    }
}